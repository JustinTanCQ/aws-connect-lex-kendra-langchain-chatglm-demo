"""Azure Cognitive Services Toolkit."""

from langchain.agents.agent_toolkits.azure_cognitive_services.toolkit import (
    AzureCognitiveServicesToolkit,
)

__all__ = ["AzureCognitiveServicesToolkit"]
