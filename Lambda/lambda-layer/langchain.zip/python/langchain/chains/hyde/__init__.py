"""Hypothetical Document Embeddings.

https://arxiv.org/abs/2212.10496
"""
